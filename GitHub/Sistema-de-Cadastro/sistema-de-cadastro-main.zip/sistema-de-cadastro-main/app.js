console.log("Rodando o sistema de gerenciamento de jogos");

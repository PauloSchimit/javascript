<h1>Sistema de Cadastro de Jogos</h1>

> Status do Projeto: Em desenvolvimento

Para rodar esse projeto na sua máquina, por favor digite:

```
npm install react
```
